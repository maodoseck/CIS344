<?php
  // create short variable name
  $document_root = $_SERVER['DOCUMENT_ROOT'];
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Maodo's Fitness Coaching - Customer Sign Ups</title>
  </head>
  <body>
    <h1>Maodo's Fitness Coaching</h1>
    <h2>Customer Sign Ups</h2> 
    <?php
    $signups = file("$document_root/../orders/fitness_orders.txt");

    $number_of_signups = count($signups);
    if ($number_of_signups == 0) {
      echo "<p><strong>No sign-ups pending.<br />
            Please try again later.</strong></p>";
    }
 
    for ($i = 0; $i < $number_of_signups; $i++) {
      echo $signups[$i] . "<br />";
    }
    ?>
  </body>
</html> 