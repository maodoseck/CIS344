<?php
  $pictures = array('workout1.png', 'food1.png', 
                    'workout2.png', 'food2.png', 
                    'workout3.png', 'food3.png');

  shuffle($pictures);  
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Maodo's Fitness Program</title>
  </head>
  <body>
    <h1>Maodo's Fitness Program</h1>
      <div align="center">
      <table style="width: 100%; border: 0">
        <tr>
        <?php
        for ($i = 0; $i < 3; $i++) {
          echo "<td style=\"width: 33%; text-align: center\">
                <img src=\"";
          echo $pictures[$i];
          echo "\"/></td>";
        }
        ?>
        </tr>
     </table>
     </div>
  </body>
</html>