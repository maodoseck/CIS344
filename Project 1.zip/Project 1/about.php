<!DOCTYPE html>
<html>
<head>
  <title>About Us - Maodo's Fitness Coaching</title>
  <link href="styles.css" type="text/css" rel="stylesheet">
</head>
<body>
  <header>    
    <h1>About Maodo's Fitness Coaching</h1>
  </header>

  <section>
    <h2>Our Mission</h2>
    <p>At Maodo's Fitness Coaching, we are passionate about helping people achieve their health and fitness goals. Whether you’re looking to lose weight, build muscle, We are here to support you.</p>
    
    <h2>Why Choose Us?</h2>
    <ul>
      <li>Certified Personal Trainers</li>
      <li>Customized Fitness Plans</li>
      <li>Nutrition Support</li>
      <li>Group Classes and Community Support</li>
    </ul>
  </section>

  <footer>
    <p>&copy; Maodo's Fitness Coaching.</p>
  </footer>
</body>
</html> 