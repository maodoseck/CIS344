<!-- page footer -->
<footer>
    <p>&copy; Maodo's Fitness Coaching.<br />
    Please see our 
    <a href="terms.php">terms and conditions</a> or our 
</footer>

</body>
</html>