<?php
  require("page.php");


  $homepage = new Page();

  $homepage->content ="<!-- page content -->
                       <section>
                       <h2>Welcome to Maodo's Fitness Coaching .</h2>
                       <p>Your journey to fitness starts here. Explore our personalized coaching services designed to help you achieve your health and fitness goals. </p>

                       </section>";
  $homepage->Display();
?>