<?php

$prices['Personal Training Session'] = 50;
$prices['Nutrition Plan'] = 30;
$prices['Workout Plan'] = 25;

while ($element = each($prices)) {
  echo $element['key'] . " – $" . $element['value'];
  echo "<br />";
}

?> 