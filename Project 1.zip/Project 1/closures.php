<?php

$printer = function($value) { echo "$value <br/>"; };

$products = [
    'Workout Plan' => 100,
    'Nutrition Guide' => 50,
    'Personal Training Session' => 30
];

$markup = 0.20;

$apply = function(&$val) use ($markup) {
    $val = $val * (1 + $markup);
};

array_walk($products, $apply);

array_walk($products, $printer);

?>