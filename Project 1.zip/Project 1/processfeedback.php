<?php


$name = $_POST['name'];
$email = $_POST['email'];
$feedback = $_POST['feedback'];


$toaddress = "maodoseck@example.com"; 

$subject = "Feedback from Maodo's Fitness Coaching";

$mailcontent = "Customer name: " .filter_var($name). "\n" .
               "Customer email: " .$email. "\n".
               "Customer comments:\n" .$feedback. "\n";

$fromaddress = "From: webserver@example.com"; 

// Invoke mail() function to send mail
mail($toaddress, $subject, $mailcontent, $fromaddress);

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Maodo's Fitness Coaching - Feedback Submitted</title>
  </head>
  <body>

    <h1>Feedback Submitted</h1>
    <p>Your feedback has been sent. Thank you for your input!</p>

  </body>
</html> 