<!DOCTYPE html>
<html>
  <head>
   <title>Maodo's Online Fitness - Fitness</title>
  </head>
  <body>
    <table style="border: 0px; padding: 3px">
    <tr>
     <td style="background: #cccccc; text-align: center;">Login</td>
     <td style="background: #cccccc; text-align: center;">Coaching Plans</td>
    </tr>

    <?php
    $login = 50;
    while ($login <= 250) {
      echo "<tr>
            <td style=\"text-align: right;\">".$login."</td>
            <td style=\"text-align: right;\">".($login / 10)."</td>
            </tr>\n";
      $login += 50;
    }
    ?>
    
    </table>
  </body>
</html>